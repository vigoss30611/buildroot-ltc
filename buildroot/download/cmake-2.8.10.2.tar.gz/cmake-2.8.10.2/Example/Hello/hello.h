#ifndef _hello_h
#define _hello_h


class Hello
{
public:
  void Print();
};

#endif
