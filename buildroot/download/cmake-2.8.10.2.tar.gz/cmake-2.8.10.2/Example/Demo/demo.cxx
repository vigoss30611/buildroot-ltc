#include "hello.h"

extern Hello hello;

int main()
{
  hello.Print();

  return 0;
}
